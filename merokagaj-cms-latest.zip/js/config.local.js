/**
 * Local configuration override (gitignored).
 * This file overrides config.js when present.
 * Do NOT commit this file — it may contain secrets.
 */
window.MEROKAGAJ_CONFIG = {
  SUPABASE_URL: 'https://txwrsqictjfxcxhwjmtj.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4d3JzcWljdGpmeGN4aHdqbXRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyODQ0NTQsImV4cCI6MjEwMTg2MDQ1NH0.z3komc6qS1zjnHgDKjYAJQNPQCAGtIodjk7tbLhnWi4',
};
